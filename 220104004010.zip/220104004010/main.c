#include<stdio.h>

//function for first part
int findGCD()
{
    int a,b;
    printf("WELCOME TO FIRST PART\n");
    //receiving input
    printf("Enter the first number\n");
    scanf("%d", &a);
    printf("Enter the second number\n");
    scanf("%d", &b);
    int biggerNum, smallerNum,GCD,remainder;
    
    //comparing inputs
    if(a<=b)
    {
        biggerNum = b;
        smallerNum = a;
    }
    else
    {
        biggerNum = a;
        smallerNum = b;       
    }

    if(biggerNum%smallerNum==0)
    {
        GCD= smallerNum;
        printf("GCD is: %d", GCD);
    }
    else
    {   
        //we are taking mod of smaller num with reminder until we find GCD.
        do
        {   
            remainder = biggerNum%smallerNum;
            if(remainder ==0)
            {
                 printf("GCD is: %d\n", smallerNum);
                 return 0;
            }
            biggerNum=smallerNum;
            smallerNum=remainder;
        } 
        while (remainder!=0);
    } 

}
//It's an additional function for second and third part.
int findDigit(int a)
    {
        int digit=0,division;
        do
        {
            division= a / 10;
            digit ++;
            a= division;
        }
        while (division!=0);
        return digit;
    }
//It's an additional function for second and third part.
int printingNumbers(int number, int digit,int blankNumber)
{
    //limit is a number of space before we print the number.
    int limit= blankNumber-digit;
    for(int i=0; i<limit; i++)
    {
        printf(" ");
    }
    printf("%d\n", number);

}
int part2()
{
    int a,b,digitFirst,digitSecond,result,digitResult;
    //function for finding digit

    printf("\nWELCOME TO SECOND PART\n");
    //receiving input
    printf("Enter the first number(max 4 digits)\n");
    scanf("%d", &a);
    digitFirst= findDigit(a);
    printf("Enter the second number(max 4 digits)\n");
    scanf("%d", &b);
    digitSecond= findDigit(b);
    

    result= a + b;
    digitResult= findDigit(result);
    //printing first and second number's values
    printf("First number :%d\n", a);
    printf("Second number :%d\n", b);
    printf("Result :\n");
    //width is 7 in the pdf.
    printingNumbers(a,digitFirst,7);
    printingNumbers(b, digitSecond, 7);
    printf("+\n");
    printf("_______\n");
    printingNumbers(result, digitResult, 7);

}

int part3()
{
    int a,b,digitFirst,digitSecond,result,digitResult,multiplyFirst,multiplySecond,multiplyThird,digitMFirst, digitMSecond,digitMThird;

    printf("WELCOME TO THIRD PART\n");
    //receiving input
    printf("Enter the first number(max 3 digits)\n");
    scanf("%d", &a);
    digitFirst= findDigit(a);
    printf("Enter the second number(max 3 digits\n");
    scanf("%d", &b);
    digitSecond= findDigit(b);
    
    //finding that how many units,tens and hundreds for the second number
    int units, tens, hundreds;
    units= b % 10;
    tens= (b /10)%10;
    hundreds= b /100;
    //the final result
    result= a * b;
    digitResult= findDigit(result);
    //first step at the multiplying
    multiplyFirst= a * units;
    digitMFirst= findDigit(multiplyFirst);
    //second step at the multiplying
    multiplySecond= a * tens;
    digitMSecond= findDigit(multiplySecond);
    //third step at the multiplying
    multiplyThird= a * hundreds;
    digitMThird= findDigit(multiplyThird);
    
    //printing first and second number's values
    printf("First number :%d\n", a);
    printf("Second number :%d\n", b);
    printf("Result :\n");

    printingNumbers(a,digitFirst,10);
    printingNumbers(b, digitSecond, 10);
    printf("*\n");
    printf("__________\n");
    printingNumbers(multiplyFirst, digitMFirst, 10);
    //checking if we have second step at multiplying
    if(tens !=0)
    {
        printingNumbers(multiplySecond, digitMSecond,9);
    }
    //checking if we have third step at multiplying
    if(hundreds !=0)
    {
        printingNumbers(multiplyThird, digitMThird,8);
    }
    printf("+\n");
    printf("__________\n");
    printingNumbers(result, digitResult, 10);
}

int part4()
{
    int num;
    printf("WELCOME TO FOURTH PART\n");
    //receiving input
    printf("Enter a number\n");
    scanf("%d",&num);
    if(0<num && num<=5)
    {
        printf("The integer you entered is less than or equal to 5");
    }
    else if(5<num && num<=10)
    {
        printf("The integer you entered is greater than 5");
    }
    else
    {
        printf("Invalid input");
    }
}


int main()
{
    findGCD();
    part2();
    part3();
    part4();
    //the program will terminated.
    return 0;
}
