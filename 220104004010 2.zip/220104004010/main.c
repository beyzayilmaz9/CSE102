#include<stdio.h>
#include<math.h>

//It's an additional function for second part.
//ıt works for printing the inputs, operation and equal sign.
int printingPattern(double firstoperand, char operation,double secondoperand)
{
    printf("%.0lf ", firstoperand);
    printf("%c ", operation);
    if(operation !='!')
    {
    printf("%.0lf ", secondoperand);
    }
    printf("= ");
}
//It's an additional function for second part.
//ıt calculates the result.
int calculate(double firstoperand, char operation,double secondoperand)
{
    double result;
    if(operation=='!')
    {
    	for(int i=1; i<=firstoperand; i++)
    	{
    		result = result * i;
    	}
    }
    else if(operation=='+')
    {
        result= firstoperand+secondoperand;
    }
    else if(operation=='-')
    {
        result= firstoperand-secondoperand;
    }
    else if(operation=='*')
    {
        result= firstoperand*secondoperand;
    }
    else if(operation=='%')
    {
        result= (int)firstoperand%(int)secondoperand;
    }
    else if(operation=='/')
    {
        result= firstoperand/secondoperand;
    }
    else if(operation=='^')
    {
    	result= pow(firstoperand, secondoperand);
    }	
    return result;
}
//It's an additional function for second part.
/*its printing result as scientific notation if user wants scientific notation. 'm' value is signed as a 0 at the first so if m is different from 0, the user changed the m number that means we should print the result as a scientific notation.*/
int showResult(double num, int m, int n)
{
    int i=0;
    //if m is still zero result is printing as usual. in 'I' format
    if(m==0)
    {
        printf("%.2lf\n",num);
        return 0;
    }
    //for scientific notation result must be between 1 to 10. in this part we are doing this also we are finding the 10's exponent(i)
    if(num>1 )
    {
        do
        {
            num = num /10.0;
            i++;
        } while (num>=10);
    }
    else
    {
        do
        {
            num = num *10.0;
            i--;
        } while (num>=10);
    }
    //finding howmany 0 must be printed before printing the actual result
    int tamsayibasamak= m-n-1;
    for(int k=0; k<tamsayibasamak;k++)
    {
        printf("0");
    }
    //printing result
    printf("%.*lf",n, num);
    printf("e%d\n", i);
}

int part1()
{
    int year;
    printf("*************************\n");
    //receiving an input
    printf("Please enter a year:");
    scanf("%d", &year);
    //leap years are divisible by four, so mod of 4 has to be 0.
    if(year%4==0)
    {
        if(year%100==0)
        {
        //if year divisible by 100, it has to be divisible by 400 too 
            if(year%400==0)
            {
                printf("%d ", year);
                printf(" ");
                printf("is a leap year.\n");
            }
            else
            {
                printf("%d", year);
                printf(" ");
                printf("is not a leap year.\n");
            }
        }
        else{
        printf("%d ", year);
        printf(" ");
        printf("is a leap year.\n");
        }
    }
    else
    {
        printf("%d", year);
        printf(" ");
        printf("is not a leap year.\n");
    }
}

int part2()
{
    //declearing variables
    int m,n;
    double firstoperand, secondoperand,result=1.0;
    char format,operation;
    printf("*************************\n");
    //receiving inputs
    printf("Enter the format of output ( S or I ):");
    scanf(" %c", &format);
    //taking m and n as an input
    if(format=='S')
    {
        //“m” is number of total digits of result and “n” is number of digits after decimal point
        printf("Enter the m and n values: "); 
        scanf("%d%d", &m ,&n);
        //Warn user if n>m
        if(n>m)
        {
            printf("ERROR");
            return 0;
        }
    }
    //taking operation
    printf("Enter the operation:(+,-,*,/,%%,!,^):");
    scanf(" %c", &operation);
    //If the user enters an invalid operator, print an error message.
    if(operation!='+'&&operation!='-'&&operation!='*'&&operation!='/'&&operation!='+'&&operation!='%'&&operation!='!'&&operation!='^')
    {
    	printf("ERROR");
    	return 0;
    }
    //taking operand inputs(for factorial calculations we are taking just one input that's why ı wrote it seperately)
    if(operation=='!')
    {
        printf("Enter the operand: ");
        scanf("%lf", &firstoperand);     
    }
    else
    {
        printf("Enter the first operand: ");
        scanf("%lf", &firstoperand);
        printf("Enter the second operand: ");
        scanf("%lf", &secondoperand);
    }
    //calculating results
    result = calculate(firstoperand, operation,secondoperand);
    //printing output
    printingPattern(firstoperand, operation,secondoperand);
    showResult(result, m,n);
    
}

int part3()
{
    ////declearing variables
    int exam1, exam2, exam3, assignment1, assignment2;
    double finalGrade;
    printf("*************************\n");
    //receiving inputs
    printf("Enter 3 exam grades of student: ");
    scanf("%d%d%d", &exam1, &exam2,&exam3);
    printf("Enter 2 assignment grades of student: ");
    scanf("%d%d", &assignment1,&assignment2);
    //checking if grades are between 0-100
    if(exam1<0||100<exam1||exam2<0||100<exam2||exam3<0||100<exam3||assignment1<0||100<assignment1||assignment2<0||100<assignment2)
    {
    	printf("Invalid input. The grade is invalid.\n");
    	return 0;
    }
    //calculating the final grade
    finalGrade = (exam1 + exam2 + exam3) / 3 * 0.6 + (assignment1 + assignment2) / 2 * 0.4;
    //printing the final grade to the screen
    printf("Final grade: %.1lf", finalGrade);
    //printing that if person passed or failed the lesson.
    if(finalGrade<60)
    {
        printf(" Failed!\n");
    }
    else
    {
        printf(" Passed!\n");
    }
}
int main()
{
    part1();
    part2();
    part3();
}
